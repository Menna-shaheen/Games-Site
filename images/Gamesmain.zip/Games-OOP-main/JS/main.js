
import { Games } from "./games.module.js";

new Games();
